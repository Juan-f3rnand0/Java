
public class Finca extends Inmueble {
    private int cantidadAnimales;

    public Finca(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, int cantidadAnimales) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.cantidadAnimales = cantidadAnimales;
    }

    public int getCantidadAnimales() {
        return cantidadAnimales;
    }

    public void setCantidadAnimales(int cantidadAnimales) {
        this.cantidadAnimales = cantidadAnimales;
    }
}


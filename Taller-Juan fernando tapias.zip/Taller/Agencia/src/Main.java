import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Ingrese los datos del inmueble:");
        System.out.print("Código: ");
        int codigoInmueble = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer del scanner
        
        System.out.print("Ciudad: ");
        String ciudadInmueble = scanner.nextLine();
        
        System.out.print("Dirección: ");
        String direccionInmueble = scanner.nextLine();
        
        System.out.print("Área: ");
        double areaInmueble = scanner.nextDouble();
        
        System.out.print("Valor metro cuadrado: ");
        double valorMetroCuadradoInmueble = scanner.nextDouble();
        
        System.out.print("Valor arriendo mensual: ");
        double valorArriendoMensualInmueble = scanner.nextDouble();
        
        Inmueble inmueble = new Inmueble(codigoInmueble, ciudadInmueble, direccionInmueble, areaInmueble, valorMetroCuadradoInmueble, valorArriendoMensualInmueble);
        
        System.out.println("\nIngrese los datos del apartamento:");
        System.out.print("Número de piso: ");
        int numeroPiso = scanner.nextInt();
        
        Apartamento apartamento = new Apartamento(codigoInmueble, ciudadInmueble, direccionInmueble, areaInmueble, valorMetroCuadradoInmueble, valorArriendoMensualInmueble, numeroPiso);
        
        System.out.println("\nIngrese los datos de la casa:");
        System.out.print("Número de habitaciones: ");
        int numeroHabitaciones = scanner.nextInt();
        
        Casa casa = new Casa(codigoInmueble, ciudadInmueble, direccionInmueble, areaInmueble, valorMetroCuadradoInmueble, valorArriendoMensualInmueble, numeroHabitaciones);
        
        System.out.println("\nIngrese los datos de la finca:");
        System.out.print("Cantidad de animales: ");
        int cantidadAnimales = scanner.nextInt();
        
        Finca finca = new Finca(codigoInmueble, ciudadInmueble, direccionInmueble, areaInmueble, valorMetroCuadradoInmueble, valorArriendoMensualInmueble, cantidadAnimales);

        System.out.println("\nValor de venta del inmueble: " + inmueble.calcularValorVenta());
        System.out.println("Valor de venta del apartamento: " + apartamento.calcularValorVenta());
        System.out.println("Valor de venta de la casa: " + casa.calcularValorVenta());
        System.out.println("Valor de venta de la finca: " + finca.calcularValorVenta());
        
        scanner.close();
    }
}




public class Inmueble {
    private int codigo;
    private String ciudad;
    private String direccion;
    private double area;
    private double valormetrocuadrado;
    private double valorarriendomensual;

    public Inmueble(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual) {
        this.codigo = codigo;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.area = area;
        this.valormetrocuadrado = valormetrocuadrado;
        this.valorarriendomensual = valorarriendomensual;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getValormetrocuadrado() {
        return valormetrocuadrado;
    }

    public void setValormetrocuadrado(double valormetrocuadrado) {
        this.valormetrocuadrado = valormetrocuadrado;
    }

    public double getValorarriendomensual() {
        return valorarriendomensual;
    }

    public void setValorarriendomensual(double valorarriendomensual) {
        this.valorarriendomensual = valorarriendomensual;
    }

    public double calcularValorVenta() {
        return area * valormetrocuadrado;
    }

    public double calcularValorVenta(double precioDolar) {
        return calcularValorVenta() * precioDolar;
    }

    public double calcularValorVenta(double precioEuro, double cambioEuro) {
        return calcularValorVenta() * precioEuro * cambioEuro;
    }
}

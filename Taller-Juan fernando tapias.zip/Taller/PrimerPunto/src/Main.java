import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String producto = "Arroz";
		String cliente = "Rosario";
		String estado = "Completada";
		double totalventa = 2.000;
		
		Scanner leer = new Scanner(System.in);
		System.out.println("Ingrese el producto: ");
		producto = leer.nextLine();
			
		System.out.println("Ingrese al cliente: ");
		cliente = leer.nextLine();
		
		System.out.println("Ingrese el estado: ");
		estado = leer.nextLine();
		
		System.out.println("Ingrese la venta total: ");
		totalventa = leer.nextDouble();
		
		Ventas ventas1 = new Ventas (producto,cliente,estado,totalventa);
		System.out.println(ventas1);
		
		
		// Llamar metodos de la clase vehiculo
		ventas1.insertarVenta();
		ventas1.actualizarVenta();
		ventas1.consultarVenta();
		ventas1.cambiarestadoVenta();
		
		leer.close();
		
	}
	
}

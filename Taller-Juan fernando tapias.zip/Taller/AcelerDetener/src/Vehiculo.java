
public class Vehiculo {

	private boolean detenido;
    private int acelerar;

    public Vehiculo() {
        this.detenido = true;
        this.acelerar = 0;
    }

    public void acelerar(int aumento) {
        if (detenido) {
            detenido = false;
        }
        acelerar += aumento;
    }

    public void detener() {
    	acelerar = 0;
        detenido = true;
    }

    public boolean isDetenido() {
        return detenido;
    }

    public int getVelocidad() {
        return acelerar;
    }

    public void setVelocidad(int velocidad) {
        this.acelerar = velocidad;
    }

    @Override
    public String toString() {
        return "Vehículo: Detenido = " + detenido + ", Velocidad = " + acelerar;
    }
}